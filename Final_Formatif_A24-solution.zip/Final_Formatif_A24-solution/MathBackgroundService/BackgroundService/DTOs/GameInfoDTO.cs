﻿using System.ComponentModel.DataAnnotations;

namespace BackgroundServiceVote.DTOs
{
    public class PlayerInfoDTO
    {
        public int NbRightAnswers { get; set; }
    }
}
