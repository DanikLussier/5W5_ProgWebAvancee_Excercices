﻿namespace BackgroundServiceMath.DTOs;

public class PlayerInfoDTO
{
    public int NbRightAnswers { get; set; }
}