﻿using System;
namespace WebAPI.Exceptions
{
	public class SeatOutOfBoundsException : Exception
    {
	}
}

